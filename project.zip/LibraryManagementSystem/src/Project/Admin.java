package Project;

import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;
public class Admin extends Login{
   public void Admin() throws  SQLException, ClassNotFoundException{
  //  public static void main(String[] args) throws  ClassNotFoundException, SQLException {
        // TODO Auto-generated method stub

         Scanner input= new Scanner(System.in);
 
         Driver d=new oracle.jdbc.driver.OracleDriver();
          DriverManager.registerDriver(d);
         Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","SELENIUM","#Ashritha17");
         Statement stmt=con.createStatement();
        
         Scanner sc=new Scanner(System.in);
    
             System.out.println("**----Welcome to the INTALIO Library Admin Page!----**");
             System.out.println("What would you like to do?");
             System.out.println("1.Choose this option  to Add User");
             System.out.println("2.Choose this option Add Book");
             
             int choice = input.nextInt();
           switch(choice) {
           //For the user to add another user
             case 1: 
            	 System.out.println("Enter User ID");
                 String UserID=input.next();

               if(UserID.length()>3) {
            	   System.out.println("UserID must be exactly 3 digits");
               System.out.println("Invalid UserID");
               System.out.println("Please try again :)");
               Admin();
               }
               else {
            
                System.out.println(" Enter Your Name:");
                String Name=input.next();
                System.out.println("Enter Gender:");
                String Gender=input.next();
                System.out.println("<_Enter the Mobilenumber_>");
                String MobileNumber=sc.next();
                if (MobileNumber.length()>10||MobileNumber.length()<10)
                {   System.out.println("Mobile Number must be exactly 10 digits");
             	 System.out.println("<Enter valid credentials>");
             	  Admin();
                }else  {
               	 
                System.out.println("<_Enter the Address_>");
                String Address=sc.next();
                System.out.println("Enter Favourite Book Category:");
                String BookCategory=input.next();
                
				ResultSet rs=stmt.executeQuery("INSERT INTO UsersDetails4 VALUES ('" + UserID + "', '" + Name + "', '" + Gender + "', '" + MobileNumber + "', '" + BookCategory + "')");

             System.out.println("The User added successfully");
             break;
                } 
               }
               //For the user to add books
             case 2:
                 System.out.println("*Enter the Book Name*");
                    String BookName=input.next();
                    System.out.println("*Enter the Category*");
                    String Category=input.next();
                    System.out.println("*Enter the Author Name*");
                    String Author=input.next();
                    System.out.println("*Enter the Language*");
                    String Language=input.next();
                    System.out.println("*Enter Publisher's name*");
                    String Publisher=input.next();	                    
                    ResultSet rs1=stmt.executeQuery("INSERT INTO Books1(BookName, Category, Author, Language, Publisher) VALUES ('" + BookName +"', '" + Category +"', '" + Author + "', '" + Language + "', '" + Publisher + "')");
            System.out.println("The Book is added successfully");
             break;
                }
           }
   

    

}





