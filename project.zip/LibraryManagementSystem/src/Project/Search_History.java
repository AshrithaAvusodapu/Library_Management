package Project;

import java.util.Scanner;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Search_History extends Student{
 public void search_history() throws SQLException {
    //public static void main(String[] args) throws ClassNotFoundException, SQLException {
        // TODO Auto-generated method stub
        String SearchBooks_Details;
        Scanner sc = new Scanner(System.in);
        System.out.println("**Welcome to Search page**");
        System.out.println("Select the Number");      
        System.out.println("What would you like to do?");
        System.out.println("1.**Click this to Search for Books**");
        System.out.println("2.**Do you want to view the history**");
        System.out.println("3.**Do you want to clear the history page**");
        
        String Query="Insert into SearchBooks_Details(BookID, AuthorName, Book_Category)"+"Values('','','')";
     
        SearchBooks_Details=sc.next();
        
        String ClearHistory;
        switch(SearchBooks_Details){      
       //Admin can search for books
        case "1":
            DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
            String oracleUrl = "jdbc:oracle:thin:@localhost:1521:xe";
       Connection con = DriverManager.getConnection(oracleUrl, "SELENIUM", "#Ashritha17");    
       Statement stmt = con.createStatement();
      

            String query1 = "Select * From SearchBooks_Details";
            ResultSet rs = stmt.executeQuery(query1);
            System.out.println("Table Created");
            while (rs.next()) {
            int id = rs.getInt("BookID");
            String AuthorName = rs.getString("Author_Name");
            String Book_Category = rs.getString("Book_Category");
            System.out.println("BookID: " + id +  " AuthorName: " + AuthorName + "Book_Category" + Book_Category);
            }
             break;
             //Admin can view history page
            case "2":
                System.out.println("_*Do you want to View the History Page?*_");
                String ViewHistory = sc.next();
                if((ViewHistory.equals("No"))) {
                    break;
                }
                else {
                    System.out.println("Here are some books which you have already searched");
                    System.out.println("<Think and glow rich>");
                    System.out.println("<You Can>");
                    System.out.println("<Power Of Your SubConsious Mind>");
                    System.out.println("<The Sceret Of Self Management>");
                }
                break;
                //Admin can clear history page
            case "3":
                System.out.println("**Clear the History Page**");
                System.out.println("*--Are You Sure you want to clear the page?--*");
                ClearHistory=sc.next();
                if((ClearHistory.equals("No"))) {
                    System.out.println("The History remains Same");
                }
                else {
                    System.out.println("The History is cleared");
                }
                break;
            default:
            System.out.println("None of the Above");
            break;
        }
        }
}

