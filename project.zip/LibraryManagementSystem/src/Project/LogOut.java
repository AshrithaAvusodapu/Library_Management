package Project;

import java.util.Scanner;

public class LogOut extends Pay {

	public void logout() {
		// TODO Auto-generated method stub
   Scanner sc=new Scanner(System.in);
   //User can log out from here
   System.out.println("Do you want log out from here?");
   String logout=sc.next();
   if ("Yes".contentEquals(logout)){
	   System.out.println("Logged Out Successfully");
	   System.out.println("**Thank you for visiting INTALIO Library**");
	   System.out.println("Have a Good Day:)");
	   //User fails to logout
   } else {
	   System.out.println("Failed to log out:(");
   }
	}

}
