package Project;

import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class Registration {
	public static final int password=8;
  public void registration() throws SQLException, ClassNotFoundException {
   
       // TODO Auto-generated method stub
	   Driver d=new oracle.jdbc.driver.OracleDriver();
	      DriverManager.registerDriver(d);
	      // Open a connection
	      Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","SELENIUM","#Ashritha17");
	      Statement stmt1=con.createStatement();
           Scanner sc=new Scanner(System.in);
           //For registering new user
           System.out.println("**___Welcome to INTALIO Library Registration Page___**");
           System.out.println("<_Enter the Username_>");
           String Username=sc.next();
           System.out.println("<_Enter the Password_>");
           String Password=sc.next();  
           if(Password.length()>password||Password.length()<password) {
               System.out.println("Password must be exactly 8 characters");
        	   System.out.println("Enter valid password");
               registration();
           }else {

           System.out.println("<_Enter the Mobilenumber_>");
           String MobileNumber=sc.next();
		if (MobileNumber.length()>10||MobileNumber.length()<10)
           {   System.out.println("Mobile Number must be exactly 10 digits");
        	 System.out.println("<Enter valid credentials>");
        	  registration();
           }else {
         
           System.out.println("<_Enter the Address_>");
           String Address=sc.next();
           ResultSet rs=stmt1.executeQuery("Insert into Registrations2 values('"+Username+"','"+Password+"','"+MobileNumber+"','"+Address+"')");

           System.out.println("You have Registered successfully..:)");

   }


}
}
}