package Project;

import java.sql.SQLException;
import java.util.Scanner;

public class Main_Module {
	 
	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		LogOut a=new LogOut();
       System.out.println("**____WELCOME TO INTALIO LIBRARY MANAGEMENT SYSTEM____**");
	System.out.println("1.Registration");
	System.out.println("2.Login"); 
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter the number"); 
	int number=sc.nextInt();
	switch(number) {
	case 1:
		a.registration();
		a.login();
		break;
	case 2:
		a.login();
		break;
	} 
	a.Admin();
	a.Student();
	a.search_history();
	a.wish_list();
	a.Pay();
	a.logout();		
}
	}
	
