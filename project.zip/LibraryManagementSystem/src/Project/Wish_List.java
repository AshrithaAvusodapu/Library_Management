package Project;


import java.sql.*;
import java.util.Scanner;

public class Wish_List extends Search_History {
 
  // Database credentials
public void wish_list() throws SQLException {
  //public static void main(String[] args) throws ClassNotFoundException, SQLException {
   
    Scanner input = new Scanner(System.in);

      // Register JDBC driver
      Driver d=new oracle.jdbc.driver.OracleDriver();
      DriverManager.registerDriver(d);
      // Open a connection
      Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","SELENIUM","#Ashritha17");
      Statement stmt1=con.createStatement();      
      Scanner sc=new Scanner(System.in);
 
        System.out.println("****Welcome to the Wish List page!****");
        System.out.println("What would you like to do?");
        System.out.println("1.**Add a book to the wish list**");
        System.out.println("2.**Remove a book from the wish list**");
        System.out.println("3.**Leave feedback on a book**");
        System.out.println("4.--> Quit");
        
        int choice = input.nextInt();
        
        switch(choice) {
        //Admin can add book to wishlist
        case 1:
          // Add a book to the wish list
          System.out.println("Enter the name of the book you would like to add:");
          String bookName = input.next();
          System.out.println("Enter the name of the author:");
          String authorName = input.next(); 
          ResultSet rs2=stmt1.executeQuery("INSERT INTO wish_List1(book_name, author_name) VALUES ('" + bookName + "', '" + authorName + "')");   
          System.out.println("Book added to wish list!");
        break;
        //Admin can remove book from wishlist
        case 2:   
          // Remove a book from the wish list
          System.out.println("Enter the name of the book you would like to remove:");
          String bookName1 = input.next();
          ResultSet rs3=stmt1.executeQuery("DELETE FROM wish_List1 WHERE book_name = '" + bookName1 + "'");       
          System.out.println("Book removed from wish list!"); 
         break;
         //Admin can provide feedback to book
         case 3:
        	  Scanner sc1 = new Scanner(System.in);   	
        	  //Insert Feedback into database
        	  System.out.println("Enter the name of the book you want to comment on:");
              String book_Name = input.next();
              System.out.println("Enter the Feedback:)");
              String FeedBack = input.next();
              ResultSet rs21=stmt1.executeQuery("INSERT INTO Feed_Back1(book_name, feedback) VALUES (' " + book_Name + " ', ' " + FeedBack + "' )");         	
        	 System.out.println("Thanks for your Feedback.Feedback submitted successfully:)");
           case 4:  
        	  System.out.println("**Thank You**");
        	  break;
          }
        	 
        	  //Clean-up environment
        	 con.close();

            }
  }
  