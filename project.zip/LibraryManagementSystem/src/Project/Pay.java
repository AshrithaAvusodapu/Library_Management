package Project;

import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class Pay extends Wish_List {
String upi, amount;
public void Pay() throws SQLException { 
        // TODO Auto-generated method stub
         Scanner input = new Scanner(System.in);

           Driver d=new oracle.jdbc.driver.OracleDriver();
              DriverManager.registerDriver(d);
              // Open a connection
              Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","SELENIUM","#Ashritha17");
              Statement stmt1=con.createStatement();      
              Scanner sc=new Scanner(System.in);

              System.out.println("****Welcome to the Payment page!****");
              System.out.println("What would you like to do?");
              System.out.println("1.**Proceed Payment with Phone pe**");
              System.out.println("2.**Proceed Payment with Paypal**");
              
              
                int choice = input.nextInt();
                switch(choice) {
                //User can proceed payment process via phone pe
                case 1:
                      
                      System.out.println("Enter the UPI id ");
                      String upi = sc.next();                   
                    System.out.println("Enter the amount"); 
                    String amount = sc.next();                 
                    System.out.println("Your Payment is Successful");
                       System.out.println("Processing your Confirmation...");
                       System.out.println("Thank you for your order");
                       
                       break;
                       //User can proceed payment process via paypal
                case 2: 
                      System.out.println("-Enter the  UserName- ");
                        String UserName=sc.next();
                        System.out.println("-Enter the Password-");
                        String Password=sc.next();
                        System.out.println("-Enter the Verification code-");
                        String Code=sc.next();
                        System.out.println("-Enter the Total Amount-");
                        int Total_Amount  =sc.nextInt();
                        ResultSet rs=stmt1.executeQuery("insert into Payment_Module1 values ('"+UserName+"','"+Password+"','"+Code+"','"+Total_Amount +"')");               
                        System.out.println("Payment successfully completed");            
           }
                  }
    }

 