package Project;

import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class Student extends Admin {

		  // Database credentials
	 
     static int bid;
		static int ans;
     
	public void Student() throws SQLException {
	    
		  //public static void main(String[] args) throws ClassNotFoundException, SQLException {
		   
		    Scanner input = new Scanner(System.in);
           
		      // Register JDBC driver
		      Driver d=new oracle.jdbc.driver.OracleDriver();
		      DriverManager.registerDriver(d);
		      // Open a connection
		      Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","SELENIUM","#Ashritha17");
		      Statement stmt1=con.createStatement();		      
		      Scanner sc=new Scanner(System.in);
		      
		      Statement st=con.createStatement();
		      int ch,id;
		      int av ;	
		      String name,classs,dept;
		      String Btitle , Bauthor = null;
		       
		      do
		      {
		    	  System.out.println("*---Student Credentials---*\n1.*Student Enrollment*\n2.*Book Enrollment*\n3.*Search By author*\n4.*Search By Title*\n5.*Book Issue*\n6.*Return*\n7.*History*\n*Enter Your Choice*");
		         Scanner sc1=new Scanner(System.in);
		         ch=Integer.parseInt(sc.nextLine());		        
		        switch(ch) {
		        //Student can enroll their details
		         case 1:
		        	 System.out.println("Enter roll no. ,Name, Dept of the student ");
		        	 id=Integer.parseInt(sc.nextLine());
		        	 name=sc.nextLine();
		        	 dept=sc.nextLine();
		        	String s1="insert into Student_Infom2 (roll_no, Name, Dept) VALUES("+id+",' "+name+" ', ' "+dept+" ')";
		           st.executeUpdate(s1);
		           System.out.println("**Details added succesfully**");
		         //Here student can enroll books details 
		      break;
		         case 2:
		        	 System.out.println("Enter Book ID, Title of Book, Author of Book, Availablity");
		        	 bid=Integer.parseInt(sc.nextLine());
		        	 Btitle=sc.nextLine();
		        	 Bauthor=sc.nextLine();
		        	 av=Integer.parseInt(sc.nextLine());
		        	 String s2="INSERT INTO Book_Inform2(bid,Btitle,Bauthor,Availability) VALUES ("+bid+",' "+Btitle+"', ' "+Bauthor+" ', '"+av+" ')";
		        	 st.executeUpdate(s2);
		        	 System.out.println("Book Insertion Successfull");
		        	 break;
		        	 //Student  can search for author's identity
		         case 3:
		        	 System.out.println("Enter author Name(First 3 characters)");
		        	 Bauthor =sc.nextLine();
		        	 String s3="SELECT * from Book_Inform2 WHERE Bauthor like ' "+Bauthor+"%'";
		        	 ResultSet rs=st.executeQuery(s3);
		        	while(rs.next()) {		      	
		        		System.out.println(rs.getString(1)+"\t"+rs.getString(2)+"\t"+rs.getString(3)+"\t"+rs.getString(4));
		        	}
			           break;
			           //Student can search for book's identity
		         case 4:
		         	 System.out.println("Enter Book Name(First 3 characters))");
		        	 Btitle=sc.nextLine();
		        	 String s4="SELECT * FROM Book_Inform2 WHERE Btitle like ' "+Btitle+"%'";
		        	 ResultSet rs1=st.executeQuery(s4);
		         while(rs1.next()) {		        		 	        		 		        	
		        		 System.out.println(rs1.getString(1)+"\t"+rs1.getString(2)+"\t"+rs1.getString(3)+"\t"+rs1.getString(4));
		        	 }

		        	 break;
		        	//Book can be issued to student
		         case 5:	
		        	 System.out.println("**Enter the Roll No**");
		        	 id=Integer.parseInt(sc.nextLine());
		        	 System.out.println("**Enter the Book id**");
		        	 bid=Integer.parseInt(sc.next());
		        	System.out.println("*--Book is Issued--*");
		        	System.out.println("*Status is Updated*");	
		        	
		        	 break;				       	 
		        //Here book can returned from student
		         case 6:
		        	 System.out.println("**Enter the Roll No**");
		        	 id=Integer.parseInt(sc.nextLine());
		        	 System.out.println("**Enter the Book id**");
		        	 bid=Integer.parseInt(sc.next());
		        	System.out.println("*--Book is Returned--*");
		        	System.out.println("*Status is Updated*");		        			        	
		        	 break;
		        	 //Student can view the status of books issuance and returning
		         case 7: 
		        	 System.out.println("**Enter roll no**");
		        	 id=Integer.parseInt(sc.nextLine());
		        	 String s9="select * from Student_Books1 where id=' "+id+" '";
		           ResultSet rs2=st.executeQuery(s9);
		           while(rs2.next()) {
		        	   System.out.println(rs2.getString(1)+"\t"+rs2.getString(2)+"\t"+rs2.getString(3)+rs2.getString(4));
		           }
		           break;
		         
		         }
		         System.out.println("Do you want to continue(1/0)");
		         int ans=sc.nextInt();
		         if(ans==1){
		        	 System.out.println("Student Credetials");
		        	 Student();
		        	 		        	 
		         }else {
		        	 System.out.println();
		         }
		      }while(ans==1);
	     		 System.out.println( );
		}
}
		      
