package Project;

import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;
public class Login extends Registration {


	public void login() throws SQLException, ClassNotFoundException {
		
		// TODO Auto-generated constructor stub
	    // TODO Auto-generated method stub
        Driver d=new oracle.jdbc.driver.OracleDriver();
         DriverManager.registerDriver(d);
        Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","SELENIUM","#Ashritha17");
        Statement stmt=con.createStatement();     
        Scanner sc=new Scanner(System.in);
        //For the user to login
            System.out.println("*------Welcome to INTALIO Library Login Page------*");
            System.out.println("**Enter the Username**");
            String Username=sc.next();
            System.out.println("**Enter the Password**");
            String Password=sc.next();
            ResultSet rs=stmt.executeQuery("select * from Registrations2 where username='"+Username+"' and password='"+Password+"'");
            if(rs.next())
            {
                System.out.println("You have successfully logged into INTALIO Library...");
                System.out.println("    *Welcome to INTALIO Library Management system*\n "+Username);              
                }else {
                    System.out.println("*Invalid Password and Username*");
                    System.out.println("Please Try again:)"); 
                    login();
                }
              
            
                con.close();
                }
              
}
    
